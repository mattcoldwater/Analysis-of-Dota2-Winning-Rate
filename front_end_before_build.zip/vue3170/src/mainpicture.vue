<template>
    <div class = "text" >
        <span class = "linecontrol">Find the best hero lineup</span>
        <span> that belongs to you</span>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss">
    .text {
        min-width: 1226px;
        height : 445px;
        background-image: url(./assets/text.png);
        background-repeat: no-repeat;
        background-position: center top;
        text-align:center;
        color:rgb(45, 49, 66);
        font-size: 70px;
        font-family: 'Amaranth', cursive, "Microsoft Yahei", ff-tisa-web-pro-1, ff-tisa-web-pro-2, "Lucida Grande", "Hiragino Sans GB", Tahoma, HELVETICA, Arial, sans-serif;
        line-height: 100px;
        background-size: 100% 100%;
        padding-top: 55px;
        margin-bottom: 0px;
        user-select: none;
        .linecontrol{
        }
    }
</style>