<template>
    <div>
        <div class = "selectcontainer" v-if ="!isshowresult">
            <div class = "changebuffer">
                <div class = "imgprocess">
                    <div>
                        <img src="../assets/role.png" alt="jermaine">
                    </div>
                    
                </div>
                <div class = "category">
                    <div class ="categorytop">You could choose 5 heroes for each lineup, and we will predict corresponding data and wining-rate. Or you could change mode to only choose five heroes, and we will predict the best five heroes for opposite and wining rate</div>
                    <div class ="categorybottom">
                        <div @click = "changecategory = 0" :class ="{ clickcategory: changecategory === 0}">{{categorythree[0]}}</div>
                        <div @click ="changecategory = 1" class ="just" :class ="{ clickcategory: changecategory === 1}">{{categorythree[1]}}</div>
                        <div @click ="changecategory = 2" class ="just" :class ="{ clickcategory: changecategory === 2}">{{categorythree[2]}}</div>
                    </div>

                </div>
                <div class = "changemode">
                    <div class = "controlbutton">
                        <div class ="textforbutton"> Change Mode</div>
                        <img src="../assets/change.png" alt="jermaine"  @click = "ischangemode =!ischangemode">
                    </div>
                    <div class = "controlbutton">
                        <div class ="textforbutton rightone">Submit</div>
                        <img src="../assets/submit.png" alt="jermaine" @click = "submitresult">
                    </div>
                </div>
            </div>

            <div class = "changeforcategory">
                <div class = "onebythree">
                    <div class ="iconfortext">
                        <img :src="imageforthreebythree[changecategory][0]" alt="hi">
                    </div>
                    <div class ="textforicon">{{categorythreebythree[changecategory][0]}}</div>
                </div>
                <div class = "onebythree">
                    <div class ="iconfortext">
                        <img :src="imageforthreebythree[changecategory][1]" alt="hi">
                    </div>
                    <div class ="textforicon">{{categorythreebythree[changecategory][1]}}</div>
                </div>
                <div class = "onebythree">
                    <div class ="iconfortext">
                        <img :src="imageforthreebythree[changecategory][2]" alt="hi">
                    </div>
                    <div class ="textforicon">{{categorythreebythree[changecategory][2]}}</div>
                </div>
            </div>

            <div class = "herolist">
                    <draggable class="div-group" tag="div" v-model="list1" v-bind="dragOptions" :move="onMove" @start="isDragging=true" @end="isDragging=false">
                        <transition-group type="transition" :name="'flip-div'">
                        <div class="div-group-item" v-for="element in list1" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}">
                            <i :class="element.fixed? 'fa fa-anchor' : 'glyphicon glyphicon-pushpin'" @click=" element.fixed=! element.fixed" aria-hidden="true"></i>
                        </div>
                        </transition-group>
                    </draggable>
                    <draggable class="div-group middleone" tag="div" v-model="list2" v-bind="dragOptions" :move="onMove" @start="isDragging=true" @end="isDragging=false">
                        <transition-group type="transition" :name="'flip-div'">
                        <div class="div-group-item" v-for="element in list2" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}">
                            <i :class="element.fixed? 'fa fa-anchor' : 'glyphicon glyphicon-pushpin'" @click=" element.fixed=! element.fixed" aria-hidden="true"></i>
                        </div>
                        </transition-group>
                    </draggable>
                    <draggable class="div-group" tag="div" v-model="list3" v-bind="dragOptions" :move="onMove" @start="isDragging=true" @end="isDragging=false">
                        <transition-group type="transition" :name="'flip-div'">
                        <div class="div-group-item" v-for="element in list3" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}">
                            <i :class="element.fixed? 'fa fa-anchor' : 'glyphicon glyphicon-pushpin'" @click=" element.fixed=! element.fixed" aria-hidden="true"></i>
                        </div>
                        </transition-group>
                    </draggable>
            </div>
            <div class = "radiantpick"> </div>
            <draggable class="leftchoose" tag="div" v-model="chooselist1" v-bind="dragOptions" :move="onMove" @start="isDragging=true" @end="isDragging=false">
                <transition-group type="transition" :name="'flip-div'">
                <div class="div-group-item" v-for="element in chooselist1" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}">
                    <i :class="element.fixed? 'fa fa-anchor' : 'glyphicon glyphicon-pushpin'" @click=" element.fixed=! element.fixed" aria-hidden="true"></i>
                </div>
                </transition-group>
            </draggable>
            <div class = "direpick"> </div>
            <draggable class="rightchoose" tag="div" v-model="chooselist2" v-bind="dragOptions" :move="onMove" @start="isDragging=true" @end="isDragging=false" v-if="!ischangemode">
                <transition-group type="transition" :name="'flip-div'">
                <div class="div-group-item" v-for="element in chooselist2" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}">
                    <i :class="element.fixed? 'fa fa-anchor' : 'glyphicon glyphicon-pushpin'" @click=" element.fixed=! element.fixed" aria-hidden="true"></i>
                </div>
                </transition-group>
            </draggable>

        </div>

        <div class = "result" v-if ="isshowresult">
            <div class = "showradianthero" >
                <div class="div-group-item" v-for="element in chooselist1" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}"></div>
            </div>
            <div class = "showradianthero"  v-if ="!ischangemode">
                <div class="div-group-item" v-for="element in chooselist2" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}"></div>
            </div>
            <div class ="controlchart" v-if ="!ischangemode">
                <ve-histogram :data="chartData1"></ve-histogram>
            </div>
            <div class ="controlchart"  v-if ="!ischangemode">
                <ve-histogram :data="chartData2"></ve-histogram>
            </div>
            <div class ="controlchart"  v-if ="!ischangemode">
                <ve-histogram :data="chartData3"></ve-histogram>
            </div>
            <div class ="controlchart"  v-if ="!ischangemode">
                <ve-histogram :data="chartData4"></ve-histogram>
            </div>
            <div class ="controlchart"  v-if ="!ischangemode">
                <ve-line :data="chartData5"></ve-line>
            </div>
            <div class ="controlchart">
                <ve-line :data="chartData6"></ve-line>
            </div>
            <div class = "showradianthero"  v-if ="ischangemode">
                <div class="div-group-item" v-for="element in chooselist3" :key="element.id" :style ="{backgroundImage: `url(`+element.image+`)`}"></div>
            </div>
        </div>
    </div>
</template>

<script>
const message =[{id: "11", localized_name: "Shadow Fiend", primary_attr: "agi", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/c760b542-cc6c-4d36-a312-43693d565618sf.jpg"},
                {id: "12", localized_name: "Phantom Lancer", primary_attr: "agi", attack_type: "Melee", legs: "2", image:"http://dota2dbpic.uuu9.com/ce78281b-47a8-402e-97bf-645c2e8874b1lancer.gif"},
                {id: "14", localized_name: "Pudge", primary_attr: "str", attack_type: "Melee", legs: "2", image:"http://dota2dbpic.uuu9.com/b4e99c9b-91e5-431e-89ca-a9fe3171120cuntitled.jpg"},
                {id: "15", localized_name: "Razor", primary_attr: "agi", attack_type: "Ranged", legs: "0", image:"http://dota2dbpic.uuu9.com/71101450-9b16-4ea4-9b44-dd6c4eb31bd5razor.jpg"},
                {id: "16", localized_name: "Sand King", primary_attr: "str", attack_type: "Melee", legs: "6", image:"http://dota2dbpic.uuu9.com/0ae7f51a-4cca-43cb-9a7f-5d6b5ba5401612345.png"},
                {id: "17", localized_name: "Storm Spirit", primary_attr: "int", attack_type: "Ranged", legs: "2", image:"http://dota2dbpic.uuu9.com/c4e5c967-dbab-4a24-aa51-7e035dc683c2ST.gif"},
                {id: "18", localized_name: "Sven", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/2bb589ad-9fa2-4093-8ec9-c2fcd12d14dc00.jpg"},
                {id: "21", localized_name: "Windranger", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/8fe40b5e-58d2-491c-847d-6564e6a0a9b2WR.gif"},
                {id: "27", localized_name: "Shadow Shaman", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/13098635-b43e-459f-88ac-0a9ec28fc9b4ss.gif"},
                {id: "28", localized_name: "Slardar", primary_attr: "str", attack_type: "Melee", legs: "0", image: "http://dota2dbpic.uuu9.com/d1e5938a-b248-45f0-9123-d6cf0be97c6bslardar_full.png"},
                {id: "41", localized_name: "Faceless Void", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/6add3463-d86a-43d8-ab96-b4211dcc3cacfv.jpg"},
                {id: "42", localized_name: "Wraith King", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/bd925caa-6b96-4a08-9748-a19e8fe7c927wraith_king_hphover.png"},
                {id: "44", localized_name: "Phantom Assassin", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/3fa185dd-95f5-4f9c-85aa-36b42b80e8bapa.jpg"},
                {id: "46", localized_name: "Templar Assassin", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/25340f33-d595-46de-bc11-2453bb83de2bta.gif"},
                {id: "47", localized_name: "Viper", primary_attr: "agi", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/67e04629-07f9-4ddf-b00e-92daba1bd70bvip.jpg"},
                {id: "48", localized_name: "Luna", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/76659a60-4ed3-4afc-aaa8-2a39eff2c0b4luna.gif"},
                {id: "13", localized_name: "Puck", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/3271d9a8-de10-4c25-9dff-52ca243c3654puck.gif"},
                {id: "45", localized_name: "Pugna", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/58a4b73c-882e-4e4d-9d5c-9499733f360dpugna.gif"},
                {id: "49", localized_name: "Dragon Knight", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/4b7d218a-36e0-4ec6-8200-a6f5e5aad704000.jpg"},
                {id: "51", localized_name: "Clockwerk", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/b511604f-9c56-49a7-8460-a1ac3f5b3adf00.jpg"},
                {id: "53", localized_name: "Nature's Prophet", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/0878a84c-30cf-434c-84c1-4a2ccf3e52fcfur.gif"},
                {id: "56", localized_name: "Clinkz", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/1579d1ab-1dd1-4d64-ac88-26e821e4f209bone.jpg"},
                {id: "57", localized_name: "Omniknight", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/01ddcdb3-fb3d-412b-a6cf-e85bc473a35a00.jpg"},
                {id: "58", localized_name: "Enchantress", primary_attr: "int", attack_type: "Ranged", legs: "4", image: "http://dota2dbpic.uuu9.com/5bf5a558-74e5-49f5-91a1-6167cf8d00ffeh.gif"},
                {id: "60", localized_name: "Night Stalker", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/23f78a12-62cd-4b0a-9757-1be4fa94f9c5123456.png"},
                {id: "61", localized_name: "Broodmother", primary_attr: "agi", attack_type: "Melee", legs: "8", image: "http://dota2dbpic.uuu9.com/aeaa2836-ef80-4ec2-b3e0-a52a318887c1br.jpg"},
                {id: "63", localized_name: "Weaver", primary_attr: "agi", attack_type: "Ranged", legs: "4", image: "http://dota2dbpic.uuu9.com/e8c69923-7795-4b67-b473-608b501423abNW.jpg"},
                {id: "77", localized_name: "Lycan", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/9d8d4257-9f31-4bac-8054-e05e4ba573291234.jpg"},
                {id: "78", localized_name: "Brewmaster", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/72c84158-dfc3-4ee4-8dff-eaf9f8707b850.jpg"},
                {id: "79", localized_name: "Shadow Demon", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/5476d96a-cb17-45de-8f17-379d0a74ab92Eredar.gif"},
                {id: "85", localized_name: "Undying", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/2946d072-dde3-4791-9385-d06f8bbd2d5aUndying.jpg"},
                {id: "91", localized_name: "Io", primary_attr: "str", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/6b01b304-66de-4204-8240-0d87048b40530.jpg"},
                {id: "92", localized_name: "Visage", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/f738ea36-5b29-4166-a9e7-fe69f8acf897vis.gif"},
                {id: "93", localized_name: "Slark", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/739da86d-40e9-4e07-b48f-1a03a8a8a3e0sg.jpg"},
                {id: "94", localized_name: "Medusa", primary_attr: "agi", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/db974a46-f31f-4740-93d1-b3faa2aa4996med.gif"},
                {id: "2", localized_name: "Axe", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/09e8f2f6-4fa7-4870-ac05-7fb7f44510fafuwang.png"},
                {id: "3", localized_name: "Bane", primary_attr: "int", attack_type: "Ranged", legs: "4", image: "http://dota2dbpic.uuu9.com/db384c7d-c523-45bb-97fb-1cc68218d751Bane.gif"},
                {id: "4", localized_name: "Bloodseeker", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/530e6ca3-d04f-41b8-891d-b3ac021c9ee2bs.jpg"},
                {id: "5", localized_name: "Crystal Maiden", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/0e06d8cf-5e9a-4c9c-b137-15fc301bee4ccm.gif"},
                {id: "6", localized_name: "Drow Ranger", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/8317769a-4246-4a30-9404-3aacc87117dedr.gif"},
                {id: "7", localized_name: "Earthshaker", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/8408006c-1f74-4bea-8685-739ab02b104800.jpg"},
                {id: "8", localized_name: "Juggernaut", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/b3ce2f49-daf9-452a-b516-fa8406d77fc4jugg.gif"},
                {id: "9", localized_name: "Mirana", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/012f6fd5-6264-4a75-a7b5-087d04da9a57pom.gif"},
                {id: "54", localized_name: "Lifestealer", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/aa4f2d3d-c660-48b3-b931-74ce10fdfc721.jpg"},
                {id: "55", localized_name: "Dark Seer", primary_attr: "int", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/57252321-1b37-495c-8ac1-f68306d5d48eDS.gif"},
                {id: "62", localized_name: "Bounty Hunter", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/cf7f3664-7a7c-4d5e-94f5-98c0c2fd0deebh.gif"},
                {id: "29", localized_name: "Tidehunter", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/508e0019-b6de-4ae2-8e00-b8428bb6d16btidehunter_full.png"},
                {id: "35", localized_name: "Sniper", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/98801bb3-0c30-4ad3-9f76-cbf30e03cf8dsniper.gif"},
                {id: "36", localized_name: "Necrophos", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/c5399443-a946-4fc8-9621-4484bfec859fNEC.gif"},
                {id: "37", localized_name: "Warlock", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/fbd48581-1c31-4077-8959-1ec0aae04eebwl.gif"},
                {id: "38", localized_name: "Beastmaster", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/523a7780-04aa-4b55-bc69-f46d4f37fff900.jpg"},
                {id: "39", localized_name: "Queen of Pain", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/d52c6851-a04d-4c52-b7cf-aba9ed104e35qop.gif"},
                {id: "40", localized_name: "Venomancer", primary_attr: "agi", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/d3faf4f9-a31e-47ef-a2f5-3e11fa7879c5veno.jpg"},
                {id: "43", localized_name: "Death Prophet", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/bfa5a815-e503-4c31-9027-0e21fab493f0qop.gif"},
                {id: "1", localized_name: "Anti-Mage", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/310d3227-3e5f-4132-bc93-8afac9d0d123am.gif"},
                {id: "50", localized_name: "Dazzle", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/d14b7a6b-4931-4dc4-aa3e-17fc6cfc00b8sp.gif"},
                {id: "64", localized_name: "Jakiro", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/7148a12f-a0ed-4307-a46b-830d278a5a00thd.gif"},
                {id: "65", localized_name: "Batrider", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/ea3ed2fa-cbb4-44ac-a06b-a9029608c2b8batrider.jpg"},
                {id: "66", localized_name: "Chen", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/ff1c3144-67cc-40e0-a08c-e86111eaca4000.jpg"},
                {id: "67", localized_name: "Spectre", primary_attr: "agi", attack_type: "Melee", legs: "0", image: "http://dota2dbpic.uuu9.com/56d8d3f3-9c6b-429a-aace-226d5e7bd524tb.jpg"},
                {id: "69", localized_name: "Doom", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/28ecc276-5596-4fd6-ab3f-0a265afd8e77123456.png"},
                {id: "68", localized_name: "Ancient Apparition", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/90fc8779-b850-47b4-8339-c76be659c645aa.jpg"},
                {id: "70", localized_name: "Ursa", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/ab520d8b-2104-4a14-97d2-1254d2aef1dcuw.gif"},
                {id: "71", localized_name: "Spirit Breaker", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/71821a46-b435-4845-8226-2f66853c5370123.png"},
                {id: "72", localized_name: "Gyrocopter", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/cc02d678-beef-4cee-931e-815b04aa513bcopter.gif"},
                {id: "73", localized_name: "Alchemist", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/531e12b3-0677-4739-b505-f6143fba7b6c00.jpg"},
                {id: "74", localized_name: "Invoker", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/99ffd3b8-0691-4922-8467-2667bf83804bKael.gif"},
                {id: "76", localized_name: "Outworld Devourer", primary_attr: "int", attack_type: "Ranged", legs: "4", image: "http://dota2dbpic.uuu9.com/e526c288-d109-4fe9-9729-69966a9c769aod.jpg"},
                {id: "22", localized_name: "Zeus", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/7be0f49d-6287-4278-9ff0-a42bbd7956cfzeus.gif"},
                {id: "34", localized_name: "Tinker", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/92a8eaa6-7141-4300-bca9-01d02f30e453tk.png"},
                {id: "52", localized_name: "Leshrac", primary_attr: "int", attack_type: "Ranged", legs: "4", image: "http://dota2dbpic.uuu9.com/1c87b008-31d1-4000-92e5-18aa5486a641TS.gif"},
                {id: "75", localized_name: "Silencer", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/255b198c-2a79-4376-b08f-b3a1783604ae00.jpg"},
                {id: "80", localized_name: "Lone Druid", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/88c02857-7c61-4488-8101-2ca5971e4748ld.gif"},
                {id: "81", localized_name: "Chaos Knight", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/032f1369-e1cd-4279-8412-89666c21e1941234567.jpg"},
                {id: "82", localized_name: "Meepo", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/c86c22f9-5f71-4e2f-be85-591a685ec500meepo.jpg"},
                {id: "83", localized_name: "Treant Protector", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/7f9a431a-5edc-470a-b4a3-370f89e51a8a00.jpg"},
                {id: "84", localized_name: "Ogre Magi", primary_attr: "int", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/7e5bbdf7-5b84-4822-90a9-8af67e46ad1c00.jpg"},
                {id: "86", localized_name: "Rubick", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/383f337c-3370-4d28-8443-081f5e95ce24gm.gif"},
                {id: "87", localized_name: "Disruptor", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/8685c877-368e-4caf-9142-5ebb2a30edccdis.gif"},
                {id: "88", localized_name: "Nyx Assassin", primary_attr: "agi", attack_type: "Melee", legs: "6", image: "http://dota2dbpic.uuu9.com/536d63ab-25a6-4b88-b052-2f20add0b32dNA.jpg"},
                {id: "89", localized_name: "Naga Siren", primary_attr: "agi", attack_type: "Melee", legs: "0", image: "http://dota2dbpic.uuu9.com/2f2648ee-5570-48db-ae45-32565bd886f5naga.gif"},
                {id: "90", localized_name: "Keeper of the Light", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/bd53f004-dcc9-4110-88e8-01736209f2b6kotl.gif"},
                {id: "10", localized_name: "Morphling", primary_attr: "agi", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/6b7f1923-67e8-4a73-bc3e-b55c53bf96edmor.gif"},
                {id: "95", localized_name: "Troll Warlord", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/79d96698-f2c0-4620-9f41-8cd6254b68caTroll.gif"},
                {id: "96", localized_name: "Centaur Warrunner", primary_attr: "str", attack_type: "Melee", legs: "4", image: "http://dota2dbpic.uuu9.com/65940f31-266e-4dec-b107-f40d4556fd000.jpg"},
                {id: "97", localized_name: "Magnus", primary_attr: "str", attack_type: "Melee", legs: "4", image: "http://dota2dbpic.uuu9.com/3dcc13b7-cd12-46bc-8884-693aaa6ddc12123456.jpg"},
                {id: "129", localized_name: "Mars", primary_attr: "str", attack_type: "Melee", legs: "2", image: "https://gamepedia.cursecdn.com/dota2_gamepedia/9/9d/Mars_icon.png"},
                {id: "30", localized_name: "Witch Doctor", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/793a1a57-0fea-4395-aa86-5add327b337fwd.gif"},
                {id: "33", localized_name: "Enigma", primary_attr: "int", attack_type: "Ranged", legs: "0", image: "http://dota2dbpic.uuu9.com/8761a23f-3238-43bf-bb03-5ecb892a4139Enigma.gif"},
                {id: "19", localized_name: "Tiny", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/7da65f49-9894-4c0b-888b-00ce495cc909000.jpg"},
                {id: "20", localized_name: "Vengeful Spirit", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/9608a806-4bf0-47a0-a4ba-20b491fa3121vs.gif"},
                {id: "23", localized_name: "Kunkka", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/670869e7-75c6-4397-825d-a0cbaef2617400.jpg"},
                {id: "25", localized_name: "Lina", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/4860461c-ae68-401a-809f-f4c7a0b63aedlina.gif"},
                {id: "31", localized_name: "Lich", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/a4b83db4-6182-4ca4-a4ad-45e7d8612819lich.gif"},
                {id: "26", localized_name: "Lion", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/7f1b22cf-8001-427b-a5d8-d7c65d45647300.jpg"},
                {id: "32", localized_name: "Riki", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/79f3f7ad-e71b-4755-bc5a-44e509c47011sa.gif"},
                {id: "59", localized_name: "Huskar", primary_attr: "str", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/8aea3dbb-d148-4ce2-93dc-06c4aeef331800.jpg"},
                {id: "98", localized_name: "Timbersaw", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/d637e928-6289-4561-8c7d-b40d96c539d000.jpg"},
                {id: "99", localized_name: "Bristleback", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/0805b392-e206-41df-9544-7ed30de171d57c1ed21b0ef41bd5df37bf8650da81cb39db3d5f.png"},
                {id: "100", localized_name: "Tusk", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/970edd19-f2bb-40b5-b9d9-8b2d31a3cf03Tusk.gif"},
                {id: "101", localized_name: "Skywrath Mage", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/bc683519-2524-4323-b275-b11218259ae1Skywrath_Mage.png"},
                {id: "102", localized_name: "Abaddon", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/a0e68aea-de06-46f2-b841-70be213b68b7Abaddon.png"},
                {id: "103", localized_name: "Elder Titan", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/73aa3fe9-be47-49e2-82b1-75d44d069c20Elder_Titan.png"},
                {id: "104", localized_name: "Legion Commander", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/14687119-de9d-4601-bb23-cc395cc5c93flegion_commander_full_.png"},
                {id: "106", localized_name: "Ember Spirit", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/4c54e1ab-0c34-4f4a-8236-26e3ffa08274legion_commander_full.png"},
                {id: "107", localized_name: "Earth Spirit", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/e037c631-cddd-41e1-899d-36db1a7d3df5legion_commander_full.png"},
                {id: "105", localized_name: "Techies", primary_attr: "int", attack_type: "Ranged", legs: "6", image: "http://dota2dbpic.uuu9.com/255d33dc-f4ff-4ba3-87c9-0da0318676c82.png"},
                {id: "109", localized_name: "Terrorblade", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/201fc99f-61af-4a07-a9cb-8ceaf6e0d3392.png"},
                {id: "110", localized_name: "Phoenix", primary_attr: "str", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/17772b4c-76ff-4f49-84c2-66d8edb21b41phoenix.png"},
                {id: "111", localized_name: "Oracle", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/2b1dc7ac-2c86-43f2-b743-61f53421bef814111513531135518.jpg"},
                {id: "112", localized_name: "Winter Wyvern", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/0a2e5008-491d-4a83-87c5-386b56501e9e3159302_hdfltouxzz1051.jpg"},
                {id: "113", localized_name: "Arc Warden", primary_attr: "agi", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/cb880d14-e6a2-4737-8fe7-dab43281e24144575.jpg"},
                {id: "108", localized_name: "Underlord", primary_attr: "str", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/279b4723-3701-4b2f-96e2-d755935777b6abyssal_underlord_hphover.png"},
                {id: "114", localized_name: "Monkey King", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "http://dota2dbpic.uuu9.com/5f813eaa-e738-4ea5-a425-f260cd01334c3159302_mk105x60.jpg"},
                {id: "120", localized_name: "Pangolier", primary_attr: "agi", attack_type: "Melee", legs: "2", image: "https://gamepedia.cursecdn.com/dota2_gamepedia/4/4e/Pangolier_icon.png?version=0ca9284b8283c2fbd8550b2be5fd9c3a"},
                {id: "119", localized_name: "Dark Willow", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "http://dota2dbpic.uuu9.com/279b4723-3701-4b2f-96e2-d755935777b6abyssal_underlord_hphover.png"},
                {id: "121", localized_name: "Grimstroke", primary_attr: "int", attack_type: "Ranged", legs: "2", image: "https://gamepedia.cursecdn.com/dota2_gamepedia/d/d7/Grimstroke_icon.png"}]
import draggable from "vuedraggable";
import axios from 'axios'
export default {
    components: {
        draggable
    },
    
    data() {
        return {
            changecategory: 0,
            categorythreebythree: [["Agile", "Strength", "Intelligence"],
                                   ["Melee","Ranged", " Only two attack type"],
                                   ["Many legs", "A few legs", "withoout legs"]],
            imageforthreebythree: [[require("../assets/agile.png"),require("../assets/strength.png"),require("../assets/zhili.png")],
                                    [require("../assets/dao.png"),require("../assets/gongjian.png"),require("../assets/funny.png")],
                                    [require("../assets/footprints.png"),require("../assets/jiaoyin.png"),require("../assets/jiaoya.png")]],
            categorythree:["Attribute", "Attack Type", "Leg"],
            list1: message.filter((hero) => {
                return hero.primary_attr === "agi";
            }),
            list2: message.filter((hero) => {
                return hero.primary_attr === "str";
            }),
            list3: message.filter((hero) => {
                return hero.primary_attr === "int";
            }),
            chooselist1: [],
            chooselist2: [],
            chooselist3:[],
            finalresult: [],
            finalresult2: [],
            editable: true,
            isDragging: false,
            delayedDragging: false,
            ischangemode: false,
            isshowresult: false,
            forhistograms: {},
            forline1: {},
            forline2: {},
            forline3: {},
            chartData1: {
                columns: ['Hero_name', 'Average_hero_damage', 'Average_duration', 'Average_tower-damage'],
                rows: [
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 },
                    { 'Hero_name': "", 'Average_hero_damage': 0, 'Average_duration': 0, 'Average_tower_damage': 0 }
                ]},
            chartData2: {
                columns: ['Hero_name', 'Avg_gold_per_min', 'Avg_xp_per_min'],
                rows: [
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0},
                    { 'Hero_name': "", 'Avg_gold_per_min': 0, 'Avg_xp_per_min': 0}
                ]},
            chartData3: {
                columns: ['Hero_name', 'Average_randiant_score', 'Average_dire_score', 'Average_kills', 'Average_deaths'],
                rows: [
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0},
                    { 'Hero_name': "", 'Average_randiant_score': 0, 'Average_dire_score': 0, 'Average_kills': 0, 'Average_deaths': 0}
                ]},
            chartData4: {
                columns: ['Hero_name', 'Avg_win'],
                rows: [
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 },
                    { 'Hero_name': "", 'Avg_win': 0 }
                ]},
            chartData5: {
                columns: ['Timeline', 'Gold_predict', 'Xp_predict'],
                rows: [
                    { 'Timeline': "1", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "2", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "3", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "4", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "5", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "6", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "7", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "8", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "9", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "10", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "11", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "12", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "13", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "14", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "15", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "16", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "17", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "18", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "19", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "20", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "21", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "22", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "23", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "24", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "25", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "26", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "27", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "28", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "29", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "30", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "31", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "32", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "33", 'Gold_predict': 0,'Xp_predict': 0 },
                    { 'Timeline': "34", 'Gold_predict': 0,'Xp_predict': 0 }
                ]},
            chartData6: {
                columns: ['Timeline', 'Avg_win'],
                rows: [
                    { 'Timeline': "0", 'Avg_win': 0.5 },
                    { 'Timeline': "10", 'Avg_win': 0 },
                    { 'Timeline': "20", 'Avg_win': 0 },
                    { 'Timeline': "30", 'Avg_win': 0 },
                    { 'Timeline': "40", 'Avg_win': 0 },
                    { 'Timeline': "50", 'Avg_win': 0 },
                    { 'Timeline': "60", 'Avg_win': 0 }
                ]},

            
        };
    },
    methods: {
        submitresult(){
            if(this.ischangemode == false){
                if(this.chooselist1.length +this.chooselist2.length != 10){
                    alert("The Heroes number is not enough");
                    return
                }
                for(var i =0; i < 5; i++){
                    this.finalresult.push(this.chooselist1[i].id)
                    this.finalresult2.push(this.chooselist1[i])
                }
                for(var j =0; j < 5; j++){
                    this.finalresult.push(this.chooselist2[j].id)
                    this.finalresult2.push(this.chooselist2[j])
                }
                let postData= new URLSearchParams()
                postData.append('hero_string', this.finalresult)
                axios.post('http://119.29.203.212/articles_histogram.php', postData)
                .then((response) =>{
                    this.forhistograms = response.data
                    console.log(this.forhistograms)
                })
                .catch((error) =>{
                    console.log(error);
                })
                
                axios.post('http://119.29.203.212/articles_line.php', postData)
                .then((response) =>{
                    this.forline1 = response.data
                    console.log(this.forline1)
                })
                .catch((error) =>{
                    console.log(error);
                })
                axios.post('http://119.29.203.212/article_first_case.php', postData)
                .then((response) =>{
                    this.forline2 = response.data
                    console.log(this.forline2)
                })
                .catch((error) =>{
                    console.log(error);
                })
            }

            if(this.ischangemode == true){
                if(this.chooselist1.length != 5){
                    alert("The Heroes number is not enough");
                    return
                }
                for(var n =0; n < 5; n++){
                    this.finalresult.push(this.chooselist1[n].id)
                }
                let postData= new URLSearchParams()
                postData.append('hero_string', this.finalresult)
                axios.post('http://119.29.203.212/article_second_case.php', postData)
                .then((response) =>{
                    this.forline3 = response.data
                    console.log(this.forline3)
                })
                .catch((error) =>{
                    console.log(error);
                })
            }
        },

        onMove({ relatedContext, draggedContext }) {
            if(relatedContext.list === this.chooselist1){
                let a = this.chooselist1.length;
                if (a == 5){
                    return false;
                }
            }
            if(relatedContext.list === this.chooselist2){
                let b = this.chooselist2.length;
                if (b == 5){
                    return false;
                }
            }
            const relatedElement = relatedContext.element;
            const draggedElement = draggedContext.element;
            return (
                (!relatedElement || !relatedElement.fixed) && !draggedElement.fixed
            );
        }
        

    },
    computed: {
        dragOptions() {
        return {
            animation: 0,
            group: "description",
            disabled: !this.editable,
            ghostClass: "ghost"
            };
        }
    },
    watch: {
        isDragging(newValue) {
      if (newValue) {
        this.delayedDragging = true;
        return;
      }
      this.$nextTick(() => {
        this.delayedDragging = false;
      });
    },
        changecategory: function(){
            let a = this.list1.concat(this.list2.concat(this.list3));
            if(this.changecategory == 0){
                this.list1 = a.filter((hero) => {
                return hero.primary_attr === "agi";})
                this.list2 = a.filter((hero) => {
                return hero.primary_attr === "str";})
                this.list3 = a.filter((hero) => {
                return hero.primary_attr === "int";})

            }
            if(this.changecategory == 1){
                this.list1 = a.filter((hero) => {
                return hero.attack_type === "Melee";})
                this.list2 = a.filter((hero) => {
                return hero.attack_type === "Ranged";})
                this.list3 = a.filter((hero) => {
                return hero.attack_type === "";})

            }
            else if(this.changecategory == 2){
                this.list1 = a.filter((hero) => {
                return hero.legs >=4;})
                this.list2 = a.filter((hero) => {
                return hero.legs < 4 && hero.legs >=2;})
                this.list3 = a.filter((hero) => {
                return hero.legs <2 ;})

            }
        },
        forline3: function(){
            this.isshowresult = true;
        },
        forline1: function(){
            this.isshowresult = true;
        },
        isshowresult: function(){
            if(this.ischangemode == false){
                for( var c = 0; c <10; c++){
                    this.chartData1.rows[c].Hero_name = this.finalresult2[c].localized_name;
                    this.chartData1.rows[c].Average_hero_damage = this.forhistograms.avg_hero_damage[c];
                    this.chartData1.rows[c].Average_duration = this.forhistograms.avg_duration[c];
                    this.chartData1.rows[c].Average_tower_damage = this.forhistograms.avg_tower_damage[c];
                    this.chartData2.rows[c].Hero_name = this.finalresult2[c].localized_name;
                    this.chartData2.rows[c].Avg_gold_per_min = this.forhistograms.avg_gold_per_min[c];
                    this.chartData2.rows[c].Avg_xp_per_min = this.forhistograms.avg_xp_per_min[c];
                    this.chartData3.rows[c].Hero_name = this.finalresult2[c].localized_name;
                    this.chartData3.rows[c].Average_randiant_score = this.forhistograms.avg_radiant_score[c];
                    this.chartData3.rows[c].Average_dire_score = this.forhistograms.avg_dire_score[c];
                    this.chartData3.rows[c].Average_kills = this.forhistograms.avg_kills[c];
                    this.chartData3.rows[c].Average_deaths = this.forhistograms.avg_deaths[c];
                    this.chartData4.rows[c].Hero_name = this.finalresult2[c].localized_name;
                    this.chartData4.rows[c].Avg_win = this.forhistograms.avg_win[c];
                }
                for( var h = 1; h < 7; h++){
                    this.chartData6.rows[h].Avg_win = this.forline2[h-1];
                }
                console.log(this.chartData5)

                for( var f = 0; f < 34; f++){
                    console.log(this.chartData5.rows)
                    console.log(this.chartData5.rows[f])
                    console.log(this.chartData5.rows[f].Gold_predict)
                    console.log(this.forline1.gold_predict[f])
                    this.chartData5.rows[f].Gold_predict = this.forline1.gold_predict[f];
                    this.chartData5.rows[f].Xp_predict = this.forline1.xp_predict[f];
                }
            }
            if(this.ischangemode == true){
                for (var p= 0; p < 6; p++){
                    this.chartData6.rows[p+1].Avg_win = this.forline3[p+5];
                }
                for( var l = 0; l < 5; l++){
                    for( var y = 0; y < 116; y++){
                        if(message[y].id == this.forline3[l]){
                            this.chooselist3.push(message[y])
                        }
                    }
                }
            }
        }

  }
      
}
</script>

<style lang="scss">
    .selectcontainer{
        .changebuffer{
            width: 1100px;
            height: 200px;
            margin: 0 auto;
            border-bottom: 3px solid #a2a9b1;
            .imgprocess{
                float: left;
                height: 200px;
                width: 300px;
                div{
                    margin-top: 70px;
                    margin-left: 170px;
                    img{
                        width:130px;
                        height:130px;
                    }
                }


            }
            .category{
            float: left;
            height: 200px;
            width: 504px;
                .categorytop{
                    font-family: tahoma,"microsoft yahei","\5FAE\8F6F\96C5\9ED1";
                    height:160px;
                    font-size:20px;
                    line-height:30px;
                    color:#222;
                }
                .categorybottom{
                    height:40px;
                    div{
                        cursor: pointer;
                        text-align: center;
                        font-family: tahoma,"microsoft yahei","\5FAE\8F6F\96C5\9ED1";
                        color:#a2a9b1;
                        line-height: 40px;
                        float:left;
                        border:3px solid #a2a9b1;
                        border-bottom: none;
                        height: 40px;
                        width: 100px;
                        border-radius: 10px;
                    }
                    .just{
                        margin-left: 90px;
                    }
                    .clickcategory{
                        border:3px solid #333;
                        border-bottom: none;
                        color:#fff;
                    }
                }
            }
            .changemode{
                float:left;
                height: 200px;
                width:250px;
                .controlbutton{
                    width:250px;
                    margin-top:10px;
                    margin-bottom: 10px;
                    height:80px;
                    .textforbutton{
                        float:left;
                        text-align:center;
                        height: 62px;
                        width:72px;
                        margin-left: 20px;
                        font-size: 20px;
                        border:3px solid #444;
                        border-radius:5px;
                        font-family: 'Amaranth', cursive, "Microsoft Yahei", ff-tisa-web-pro-1, ff-tisa-web-pro-2, "Lucida Grande", "Hiragino Sans GB", Tahoma, HELVETICA, Arial, sans-serif;
                    }
                    .rightone{
                            line-height:65px;
                        }
                    img{
                        padding-top:1px;
                        padding-left:10px;
                        float: left;
                        width: 65px;
                        height: 65px;
                        &:hover{
                            width: 75px;
                            height: 75px;
                            cursor:pointer;
                        }
                    }
                }
            }

        }
        .changeforcategory{
            text-align: center;
            width: 1000px;
            height: 100px;
            margin: 0 auto;
            border-bottom:2px solid #a2a9b1;
            .onebythree{
                width: 33.3%;
                float:left;
                height: 100px;
                .iconfortext{
                    height: 70%;
                    width:70px;
                    margin: 5px auto 0px;
                    img{
                        height: 70px;
                        width: 70px;
                    }
                }
                .textforicon{
                    font-family:tahoma,"microsoft yahei","\5FAE\8F6F\96C5\9ED1";
                    user-select: none;
                    color: #aaa;
                    margin-top:-10px;
                    height:35px;
                    font-size: 28px;
                    line-height:35px;

                }
            }

        }
        
        .herolist{
            width:1000px;
            height: 800px;
            margin: 0 auto;
            .middleone{
                border-left:1px solid #a2a9b1;
                border-right:1px solid #a2a9b1;
            }
        }

    }

    .flip-div-move {
        transition: transform 0.5s;
    }
    .no-move {
        transition: transform 0s;
    }
    .ghost {
        opacity: 0.5;
        background: #c8ebfb;
    }
    .div-group {
        float:left;
        width: 33.2%;
        min-height: 60px;
    }
    .div-group-item {
        float: left;
        width:50px;
        height:50px;
        border-radius:5px;
        background-size: 100% 100%;
        cursor: move;
        margin:7.5px;
    }
    .div-group-item i {
        cursor: pointer;
    }
    .col-md-3{
        float:left;
    }
    .leftchoose{
        position: fixed;
        left: 20px;
        top: 200px;
        height:325px;
        width: 65px;
        background-color:rgba(11,11,11,0.5);
        border-radius:5px;
    }

    .rightchoose{
        position: fixed;
        right: 20px;
        top: 200px;
        height:325px;
        width: 65px;
        background-color:rgba(11,11,11,0.5);
        border-radius:5px;
    }
    span{
        display:block;
        min-height:65px;
        min-width:65px;
    }
    .result{
        height:2000px;
        width:1000px;
        margin: 0 auto;
        .controlchart{
        width: 1000px;
        height: 400px;
        margin: 20px auto;
        }
    }
    .radiantpick{
        position:fixed;
        height:105px;
        width:100px;
        left:0px;
        top: 95px;
        background-image: url(../assets/left.png);
        background-size: 100% 100%;
        background-repeat: no-repeat;
    }
    .direpick{
        position:fixed;
        height:100px;
        width:100px;
        right:0px;
        top: 100px;
        background-image: url(../assets/right.png);
        background-size: 100% 100%;
        background-repeat: no-repeat;
    }
    .showradianthero{
        width: 325px;
        height: 65px;
        margin: 5px auto;
    }

    
</style>