<template>
    <div id="footer">
        Designed by CSC3170 Group
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss">
    #footer{
        z-index: 2;
        background-image:url(./assets/footer.png);
        background-size: contain;
        color:#333;
        clear:both;
        text-align:center;
        line-height: 190px;
        padding:5px;
        height: 100px;
        position: fixed;
        bottom: 0px;
        width: 100%;
        font-family:tahoma,"microsoft yahei","\5FAE\8F6F\96C5\9ED1";
    }
    
</style>