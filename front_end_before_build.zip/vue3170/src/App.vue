<template>
  <div > 
    <v-header> </v-header>
    <v-mainpicture> </v-mainpicture>
    <v-show> </v-show>
    <div>
      <v-selectlist v-if ="showselect"></v-selectlist>
      <v-result v-if ="!showselect"></v-result>
    </div>
    <v-footer> </v-footer>
    <v-jermaine> </v-jermaine>
  </div>
  
</template>

<script>
  import result  from './components/result.vue'
  import selectlist  from './components/selectlist.vue'

  export default {
    name: 'app',
    components:{
      'v-result': result,
      'v-selectlist': selectlist
    },
    data() {
      return {
        showselect: false
      }
    },


  }
</script>

<style lang="scss">
  *{
    padding:0px;
    margin:0px;
    text-decoration: none;
    list-style-type: none;
  }
  body{
      margin: 0;
      min-width: 1226px;
      height:2500px;
      background-color: rgb(56, 89, 102);
      animation: animatebg ease 10s infinite;
  }
  @keyframes animatebg {
        0% { background: rgb(56, 89, 102); }
        25% { background: rgb(45, 49, 66); }
        50% {background: #884d4d;}
        75% { background: rgb(167, 118, 167); }
        100% { background: rgb(56, 89, 102); }
    }  
  


</style>
