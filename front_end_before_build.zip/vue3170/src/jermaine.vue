<template>
    <div class = "move" :style = "changeit" @mousemove = "updataicon"> 
    </div>
</template>

<script>
export default {
    data() {
        return {
            x:0,
            y:0,
            xchange:970,
            ychange:240
        }
    },

    watch: {
        x: function(){
            var bufferx = Math.random() < 0.5 ? -5 : 5;
            var buffery = Math.random() < 0.5 ? -5 : 5;
            this.xchange += bufferx;
            this.ychange += buffery;
        }
    },

    methods: {
        updataicon: function(e){
            this.x = e.clientX;
            this.y = e.clientY;
        }
        
    },
    computed: {
        changeit (){
            return {
                left: `${this.xchange}px`,
                top: `${this.ychange}px`
            }
        }
    },
  
}
</script>

<style lang="scss">
    .move{
      background-image:url(./assets/Jermaineeee.png);
      z-index:1;
      position:fixed;
      width: 100px;
      height: 80px;
      background-repeat: no-repeat;
      background-position: center top;
      background-size: 100% 100%;
    }
    
</style>