import Vue from 'vue'
import App from './App.vue'
import header from './header.vue'
import mainpicture from './mainpicture.vue'
import footer from './footer.vue'
import jermaine from './jermaine.vue'
import show from './show.vue'
import VeLine from 'v-charts/lib/line.common'
import VeHistogram from 'v-charts/lib/histogram.common'


Vue.config.productionTip = false
Vue.component('v-header', header)
Vue.component('v-mainpicture', mainpicture)
Vue.component('v-footer', footer)
Vue.component('v-jermaine', jermaine)
Vue.component('v-show',show)
Vue.component('ve-line', VeLine)
Vue.component('ve-histogram', VeHistogram)


new Vue({
  render: h => h(App),
}).$mount('#app')
