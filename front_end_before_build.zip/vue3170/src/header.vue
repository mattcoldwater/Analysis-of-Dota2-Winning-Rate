<template>
    <div class ="header">
        <ul class = "headerlist">
            <li><a href="#footer">Reference</a></li>
            <li><a href="http://119.29.203.212/dist/index.html">Refresh</a></li>
            <li><a href="https://www.opendota.com">Data resource</a></li>
            <li><a href="http://119.29.203.212/dist/index.html">Change Mode</a></li>
            <li style="float:left"><a href="http://119.29.203.212/dist/index.html">Home</a></li>
            <li style="float:left"><a href="http://140.138.150.147/~student/Group17/main.php">Former Site</a></li>
        </ul>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss">
    .header{
        min-width: 1226px;
        .headerlist{
            overflow: hidden;
            background-color:rgb(87, 121, 155);
            li{
                float: right;
                a{
                    display:block;
                    color:white;
                    font-family: 'Delius', cursive;
                    text-align:center;
                    padding:14px 16px;
                    text-decoration: none;
                    &:hover{
                        background-color:#884d4d;
                        color: rgb(167, 118, 167);
                        font-family: 'Delius', cursive;
                        text-decoration:none;
                        font-size: 20px;
                    }
                }
            }
        }
    }
</style>