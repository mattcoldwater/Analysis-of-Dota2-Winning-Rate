<template>
  <div class="slider">
    <div class="window" @mouseover="stop" @mouseleave="play">
      <ul class="inside" :style="containerStyle">
        <li>
          <img :src="sliders[sliders.length - 1].img" alt="hi">
        </li>
        <li v-for="(item, index) in sliders" :key="index">
          <img :src="item.img" alt="hi">
        </li>
        <li>
          <img :src="sliders[0].img" alt="hi">
        </li>
      </ul>
      <ul class="direction">
        <li class="left" @click="move(900, 1, speed)">
            <span class = "topicon iconfontshow"> &#xe6a7 </span>
        </li>
        <li class="right" @click="move(900, -1, speed)">
            <span class = "topicon iconfontshow"> &#xe6a6 </span>
        </li>
      </ul>
      <ul class="dots">
        <li v-for="(dot, i) in sliders" :key="i" 
        :class="{dotted: i === (currentIndex-1)}" @click="jump(i+1)">
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'slider',
  props: {
    initialSpeed: {
      type: Number,
      default: 30
    },
    initialInterval: {
      type: Number,
      default: 4
    }
  },
  data () {
    return {
      sliders:[
        {
          img:require("./assets/dota2-1.jpeg")
        },
        {
          img:require("./assets/dota2-2.jpg")
        },
        {
          img:require("./assets/dota2-3.jpg")
        },
        {
          img:require("./assets/dota2-4.jpg")
        },
        {
          img:require("./assets/dota2-5.jpeg")
        }
      ],
      currentIndex:1,
      distance:-900,
      transitionEnd: true,
      speed: this.initialSpeed
    }
  },
  computed:{
    containerStyle() { 
      return {
        transform:`translate3d(${this.distance}px, 0, 0)`
      }
    },
    interval() {
      return this.initialInterval * 1000
    }
  },
  mounted() {
    this.init()
  },
  methods:{
    init() {
      this.play()
      window.onblur = function() { this.stop() }.bind(this)
      window.onfocus = function() { this.play() }.bind(this)
    },
    move(offset, direction, speed) {
      if (!this.transitionEnd) return
      this.transitionEnd = false
      direction === -1 ? this.currentIndex += offset/900 : this.currentIndex -= offset/900
      if (this.currentIndex > 5) this.currentIndex = 1
      if (this.currentIndex < 1) this.currentIndex = 5

      const destination = this.distance + offset * direction
      this.animate(destination, direction, speed)
    },
    animate(des, direc, speed) {
      if (this.temp) { 
        window.clearInterval(this.temp)
        this.temp = null 
      }
      this.temp = window.setInterval(() => {
        if ((direc === -1 && des < this.distance) || (direc === 1 && des > this.distance)) {
          this.distance += speed * direc
        } else {
          this.transitionEnd = true
          window.clearInterval(this.temp)
          this.distance = des
          if (des < -4500) this.distance = -900
          if (des > -900) this.distance = -4500
        }
      }, 20)
    },
    jump(index) {
      const direction = index - this.currentIndex >= 0 ? -1 : 1
      const offset = Math.abs(index - this.currentIndex) * 900
      const jumpSpeed = Math.abs(index - this.currentIndex) === 0 ? this.speed : Math.abs(index - this.currentIndex) * this.speed 
      this.move(offset, direction, jumpSpeed)
    },
    play() {
      if (this.timer) {
        window.clearInterval(this.timer)
        this.timer = null
      }
      this.timer = window.setInterval(() => {
        this.move(900, -1, this.speed)
      }, this.interval)
    },
    stop() {
      window.clearInterval(this.timer)
      this.timer = null
    }
  }
}

</script>



<style lang="scss" >
    ul{
        padding:0px;
        margin:0px;
        list-style-type:none;
        text-decoration:none;
    }

    .slider{
        width:100%;
        height : 300px;
        .window{
            border-radius: 10px;
            overflow: hidden;
            position:relative;
            width:900px;
            height : 300px;
            margin:0 auto;
            .inside{
                position:absolute;
                z-index:1;
                width:6300px;
                padding:0px;
                li{
                    float:left;
                    height:300px;
                    width:900px;
                    padding:0px;
                    margin:0px;
                    img{
                        height:300px;
                        width:900px;
                    }

                }
            }
            .direction{
                position:absolute;
                width:900px;
                top:140px;
                z-index:2;
                height:40px;
                .left{
                    float:left;
                    width:50px;
                }
                .right{
                    float:right;
                    width:50px;
                }

            }
            .dots{
                position:absolute;
                top:250px;
                width:150px;
                height:30px;
                z-index:2;
                left:400px;
                list-style-image:url('./assets/dot.png');
                li{
                    float:left;
                    height: 30px;
                    width:20px;
                    margin-left:10px;
                    cursor: pointer;
                    
                }
            }
            .dotted{
                        list-style-image:url('./assets/dot_a.png');
                    }


        }
        
    }
    .topicon{
        line-height: 40px;
        color: bisque;
        &:hover{
            color: rgb(219, 117, 14);
            font-size: 50px;
            cursor:pointer;
        }

    }
    .iconfontshow {
        font-family:"iconfont" !important;
        font-size:40px;font-style:normal;
        -webkit-font-smoothing: antialiased;
        -webkit-text-stroke-width: 0.2px;
        -moz-osx-font-smoothing: grayscale;
        user-select: none;
    }
    
    @font-face {
    font-family: 'iconfont';  /* project id 1091738 */
    src: url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.eot');
    src: url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.eot?#iefix') format('embedded-opentype'),
    url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.woff2') format('woff2'),
    url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.woff') format('woff'),
    url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.ttf') format('truetype'),
    url('//at.alicdn.com/t/font_1091738_cktwtdt9jd.svg#iconfont') format('svg');
    }
    
</style>